# gallery website
potentially my new website design.
will feature a nice responsive grid and individual project pages.
